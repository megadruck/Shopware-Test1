<?php

namespace Shopware\Components\SwagImportExport\Exception;

/**
 * ImportExport Exception
 */
class AdapterException extends \Enlight_Exception
{
}
