<?php
namespace Shopware\Components\SwagImportExport\DataType;

class ArticlePriceDataType
{
    /**
     * @var array
     */
    public static $defaultFieldsValues = array (
        'float' => array(
            'percent'
        )
    );
}