<?php

namespace Shopware\Components\SwagImportExport\FileIO;

class ExcelFileReader implements FileReader
{
    /**
     * @param $fileName
     */
    public function readHeader($fileName)
    {
    }

    /**
     * @param $fileName
     * @param $position
     * @param $count
     */
    public function readRecords($fileName, $position, $count)
    {
    }

    /**
     * @param $fileName
     */
    public function readFooter($fileName)
    {
    }
}
