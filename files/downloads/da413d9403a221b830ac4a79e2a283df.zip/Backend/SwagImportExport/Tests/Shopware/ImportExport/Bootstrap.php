<?php

namespace Tests\Shopware\ImportExport;

include __DIR__ . '/../../../../../../../../../tests/Shopware/TestHelper.php';
Shopware()->Loader()->registerNamespace('Tests\Shopware\ImportExport', __DIR__ . '/');
