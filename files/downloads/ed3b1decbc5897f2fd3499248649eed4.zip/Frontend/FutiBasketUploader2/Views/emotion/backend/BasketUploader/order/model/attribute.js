//{block name="backend/order/model/position_attribute/fields" append}
{ name: 'futiUploadData', type: 'string', useNull: true },
//{/block}