[1.0.1]
* Änderungen bei der Configuration des Server Pfads
[1.0.0]
* Initiale Veröffentlichung
