//

// {block name="backend/swag_custom_products/view/option/types/imageupload"}
Ext.define('Shopware.apps.SwagCustomProducts.view.option.types.Imageupload', {
    extend: 'Shopware.apps.SwagCustomProducts.view.option.types.Fileupload'
});
//{/block}
