/**
 * Grid which displays the assigned products which belong to the called template.
 */

//{namespace name="backend/swag_custom_products/detail/article"}
//{block name="backend/swag_custom_products/view/detail/article"}
Ext.define('Shopware.apps.SwagCustomProducts.view.detail.Article', {
    extend: 'Shopware.grid.Association',
    alias: 'widget.template-view-detail-article',
    height: 300,

    /**
     * @type { Object }
     */
    snippets: {
        title: '{s name="title"}Products{/s}',
        columns: {
            name: {
                header: '{s name="columns/name/header"}Name{/s}'
            },
            number: {
                header: '{s name="columns/number/header"}Product number{/s}'
            }
        },
        errorMessage: {
            title: '{s name="error_message/title"}Article has been selected already{/s}',
            text: '{s name="error_message/text"}The selected article [0] is already assigned to <strong>[1]</strong>.{/s}',
            fallbackName: '{s name="error_message/fallback_name"}this template{/s}'
        }
    },

    /**
     * @returns { Object }
     */
    configure: function () {
        var me = this;

        me.title = me.snippets.title;

        return {
            controller: 'SwagCustomProducts',
            columns: {
                name: {
                    header: me.snippets.columns.name.header
                },
                number: {
                    header: me.snippets.columns.number.header
                }
            }
        }
    },

    /**
     * @returns { Array }
     */
    createActionColumnItems: function () {
        var me = this,
            items = me.callParent(arguments);

        items.push(me.createProductDetailColumn());

        return items;
    },

    /**
     * @returns { Object }
     */
    createProductDetailColumn: function () {
        return {
            action: 'openArticle',
            iconCls: 'sprite-inbox',
            handler: function (view, rowIndex, colIndex, item, opts, record) {
                Shopware.app.Application.addSubApplication({
                    name: 'Shopware.apps.Article',
                    action: 'detail',
                    params: {
                        articleId: record.get('id')
                    }
                });
            }
        };
    },

    /**
     * Creates a search combo box for selecting and searching products.
     *
     * @param store { Ext.data.Store }
     * @returns { Shopware.form.field.Search }
     */
    createSearchCombo: function (store) {
        var me = this;

        return Ext.create('Shopware.form.field.Search', {
            name: 'associationSearchField',
            store: store,
            pageSize: 20,
            flex: 1,
            subApp: me.subApp,
            fieldLabel: me.searchComboLabel,
            margin: 5,
            multiSelect: true,
            listeners: {
                select: function (combo, records) {
                    var record = records[records.length - 1],
                        responseData;

                    Ext.Ajax.request({
                        url: '{url action="validateArticleSelectionAjax"}',
                        params: { id: record.get('id') },
                        success: function (response) {
                            responseData = Ext.JSON.decode(response.responseText);
                            me.successSelectArticleCallback(responseData, combo, records);
                        }
                    });
                }
            }
        });
    },

    /**
     * Callback function for the ajax validation request.
     *
     * @param { Array } responseData
     * @param { Ext.form.field.ComboBox } combo
     * @param { Array } records
     */
    successSelectArticleCallback: function (responseData, combo, records) {
        var me = this,
            record = records[records.length - 1];

        if (responseData.success) {
            me.onSelectSearchItem(combo, records);
        } else {
            me.onFailSelectedItem(combo, record.get('number'), responseData.data.internal_name);
        }
    },

    /**
     * Override to validate if the product already exist in the product store.
     *
     * @param { Ext.form.field.ComboBox } combo
     * @param { Array } records
     * @returns
     */
    onSelectSearchItem: function (combo, records) {
        var me = this,
            record = records[records.length - 1];

        if (me.gridStoreHasArticle(combo, record)) {
            me.onFailSelectedItem(combo, record.get('number'), me.getTemplateInternalName());
            return;
        }

        return me.callParent(arguments);
    },

    /**
     * Creates a growl message and deletes the selected value if the product is assigned to another template.
     *
     * @param { Ext.form.field.ComboBox } combo
     * @param { String } number
     * @param { String } internalName
     */
    onFailSelectedItem: function (combo, number, internalName) {
        var me = this;

        Shopware.Notification.createGrowlMessage(
            me.snippets.errorMessage.title,
            Ext.String.format(me.snippets.errorMessage.text, number, internalName)
        );
        combo.setValue('');
    },

    /**
     * @returns { String }
     */
    getTemplateInternalName: function () {
        var me = this;

        if (me.up('window').record.get('internalName')) {
            return me.up('window').record.get('internalName');
        }
        return me.snippets.errorMessage.fallbackName;
    },

    /**
     * @param { Ext.form.field.ComboBox } combo
     * @param { Ext.data.Model } record
     * @returns { boolean }
     */
    gridStoreHasArticle: function (combo, record) {
        var me = this;

        if (me.store.findExact('id', record.get('id')) < 0) {
            return false;
        }
        return true;
    }
});
//{/block}