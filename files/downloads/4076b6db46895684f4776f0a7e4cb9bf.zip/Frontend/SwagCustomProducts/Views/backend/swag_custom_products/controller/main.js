//{block name="backend/swag_custom_products/controller/main"}
Ext.define('Shopware.apps.SwagCustomProducts.controller.Main', {
    /**
     * extends from the standard ExtJs Controller
     */
    extend: 'Enlight.app.Controller',

    /**
     * @type { Shopware.window.Listing }
     */
    mainWindow: null,

    /**
     * Adds events, loads stores and creates the main window for this plugin.
     */
    init: function () {
        var me = this;

        me.createMainWindow();

        me.callParent(arguments);

        // Support for directly opening a new custom product with a product association or
        // directly opening an existing custom product.
        if (me.subApplication.hasOwnProperty('state') && me.subApplication.hasOwnProperty('params')) {
            var params = me.subApplication.params,
                state = me.subApplication.state;

            if (state === 'newCustomProduct') {
                me.openNewCustomProductWithAssociatedProduct(params.product);
            } else if (state === 'existingCustomProduct') {
                me.openExistingCustomProduct(params.customProduct);
            }
        }

        // on Successfully save we reload the record and reopen the window for a clean record and view.
        Shopware.app.Application.on('template-save-successfully', function (controller, data, window, record) {
            record.reload({
                callback: function (result) {
                    me.recordReloadCallback(result, controller, data, window)
                }
            });
        });
    },

    /**
     * Creates the main window which displays the template listing
     *
     * @return { Enlight.app.Window }
     */
    createMainWindow: function () {
        var me = this;

        me.mainWindow = me.getView('overview.Window').create().show();

        return me.mainWindow;
    },

    /**
     * Provides a new preset to the user with a product association.
     *
     * @param { Object } product
     * @returns void
     */
    openNewCustomProductWithAssociatedProduct: function(product) {
        var me = this,
            gridPanel = me.mainWindow.gridPanel,
            record = gridPanel.createNewRecord(),
            productDetails = product.getMainDetailStore.data.get(0),
            productModel = Ext.create('Shopware.apps.SwagCustomProducts.model.Article', product.raw);

        productModel.set('number', productDetails.get('number'));

        record.getArticles().add(productModel);

        gridPanel.fireEvent(gridPanel.eventAlias + '-add-item', gridPanel, record);
    },

    /**
     * Opens up an existing custom product preset to start editing right away.
     *
     * @param { Object } customProduct
     */
    openExistingCustomProduct: function(customProduct) {
        var me = this,
            gridPanel = me.mainWindow.gridPanel,
            controller = gridPanel.controller,
            record = Ext.create('Shopware.apps.SwagCustomProducts.model.Template');

        record.set(customProduct);

        // We're reloading the record to fetch all necessary data using the associated proxy.
        record.reload({
            callback: function(refreshedRecord) {
                controller.createDetailWindow(
                    refreshedRecord,
                    gridPanel.getConfig('detailWindow')
                );
            }
        });
    },

    /**
     * After a successfully reload of the record we close and reopen the window.
     *
     * @param { Ext.data.Model } result
     * @param { Enlight.app.Controller } controller
     * @param { object } data
     * @param { Ext.window.Window } window
     */
    recordReloadCallback: function (result, controller, data, window) {
        var me = this,
            // get the current windowPosition
            index = 0,
            top = window.y,
            left = window.x;

        try {
            index = window.tabPanel.activeTab.index;
        } catch (e) {
        }

        // destroy the window and create a new one
        // this is a workaround for prevent the deep association displaying-bug.
        window.destroy();
        window = Ext.create('Shopware.apps.SwagCustomProducts.view.detail.Window', {
            record: result
        }).show().setPosition(left, top, false);

        // set the tabIndex
        try {
            window.tabPanel.setActiveTab(index);
        } catch (e) {
        }

        // reload the listingStore to display the new template
        me.mainWindow.listingStore.load();
    }
});
//{/block}
