/**
 * The detail window for a custom products template.
 */
//{namespace name="backend/swag_custom_products/detail/window"}
//{block name="backend/swag_custom_products/view/detail/window"}
Ext.define('Shopware.apps.SwagCustomProducts.view.detail.Window', {
    alias: 'widget.swag-custom-products-detail-window',
    extend: 'Shopware.window.Detail',

    modal: true,

    height: 700,
    width: 800,

    /**
     * @type { Object }
     */
    snippets: {
        title: {
            create: '{s name="title/create"}Create template{/s}',
            edit: '{s name="title/edit"}Edit template - [0]{/s}'
        }
    },

    /**
     * Returns the configuration of this component.
     *
     * @overwrite
     * @returns { Object }
     */
    initComponent: function () {
        var me = this;
        me.title = me.getTitle();

        // Proxy the save event and expose it to the shopware application to react to it globally.
        me.on('template-save', function() {
            Ext.defer(function() {
                Shopware.app.Application.fireEvent('SwagCustomProducts-onSave');
            }, 1500);
        });

        me.callParent(arguments);
    },

    /**
     * @overwrite
     */
    configure: function () {
        return {
            associations: [
                'options',
                'articles'
            ],
            translationKey: 'customProductTemplateTranslations'
        }
    },

    /**
     * @returns { String }
     */
    getTitle: function () {
        var me = this;

        if (me.record.get('internalName')) {
            return Ext.String.format(me.snippets.title.edit, me.record.get('internalName'));
        }
        return me.snippets.title.create;
    },

    /**
     * Method overriding to pass the template record into other components
     *
     * @param type { String }
     * @param model { Shopware.data.Model }
     * @param store { Ext.data.Store }
     * @param association { Ext.data.Association }
     * @param baseRecord { Shopware.data.Model }
     * @returns { Ext.container.Container } | { Ext.grid.Panel }
     */
    createAssociationComponent: function (type, model, store, association, baseRecord) {
        var me = this;

        var component = me.callParent(arguments);
        component.templateRecord = me.record;

        return component;
    },

    /**
     * Sets the indexes of the tab items to reload the window at the current activated tab.
     *
     * @returns { Array }
     */
    createTabItems: function () {
        var me = this;
        var items = me.callParent(arguments);

        items.forEach(function (item, index) {
            item.index = index;
        });

        return items;
    }
});
//{/block}
