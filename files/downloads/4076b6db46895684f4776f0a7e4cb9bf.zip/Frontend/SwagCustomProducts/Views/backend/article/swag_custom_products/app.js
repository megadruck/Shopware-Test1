//{namespace name="backend/article/swag_custom_products"}

//{block name="backend/article/application"}

//{$smarty.block.parent}

//{include file="backend/article/swag_custom_products/views/fieldset.js"}

//

//{/block}
