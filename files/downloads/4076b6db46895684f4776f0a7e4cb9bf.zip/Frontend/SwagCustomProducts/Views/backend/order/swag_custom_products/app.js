//{namespace name="backend/order/swag_custom_products"}

//{block name="backend/order/application"}

//{$smarty.block.parent}

//{include file="backend/order/swag_custom_products/views/detail/position.js"}

//{include file="backend/order/swag_custom_products/views/detail/swag_custom_products_details.js"}

//

//{/block}
