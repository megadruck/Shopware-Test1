<?php

/**
 * Shopware Premium Plugins
 * Copyright (c) shopware AG
 *
 * According to our dual licensing model, this plugin can be used under
 * a proprietary license as set forth in our Terms and Conditions,
 * section 2.1.2.2 (Conditions of Usage).
 *
 * The text of our proprietary license additionally can be found at and
 * in the LICENSE file you have received along with this plugin.
 *
 * This plugin is distributed in the hope that it will be useful,
 * with LIMITED WARRANTY AND LIABILITY as set forth in our
 * Terms and Conditions, sections 9 (Warranty) and 10 (Liability).
 *
 * "Shopware" is a registered trademark of shopware AG.
 * The licensing of the plugin does not imply a trademark license.
 * Therefore any rights, title and interest in our trademarks
 * remain entirely with us.
 */

namespace ShopwarePlugins\SwagCustomProducts\Components\Services;

use Doctrine\DBAL\Connection;
use Shopware\Bundle\StoreFrontBundle\Service\ContextServiceInterface;
use Shopware\Bundle\StoreFrontBundle\Service\MediaServiceInterface;
use ShopwarePlugins\SwagCustomProducts\Components\Calculator;
use Shopware\Components\DependencyInjection\Container;
use ShopwarePlugins\SwagCustomProducts\Components\FileUpload\FileTypeWhitelist;
use ShopwarePlugins\SwagCustomProducts\Components\Types\Types\ImageUploadType;

class TemplateService
{
    /** @var MediaServiceInterface $mediaService */
    private $mediaService;

    /** @var ContextServiceInterface $contextService */
    private $contextService;

    /**@var Connection $connection */
    private $connection;

    /** @var Calculator $calculator */
    private $calculator;

    /**
     * @param MediaServiceInterface $mediaService
     * @param ContextServiceInterface $contextService
     * @param Connection $connection
     * @param Container $container
     */
    public function __construct(
        MediaServiceInterface $mediaService,
        ContextServiceInterface $contextService,
        Connection $connection,
        Container $container
    ) {
        $this->mediaService = $mediaService;
        $this->contextService = $contextService;
        $this->connection = $connection;
        $this->calculator = new Calculator($container, $this);
    }

    /**
     * @param integer $productId
     * @param boolean $enrichTemplate
     * @return mixed|null
     */
    public function getTemplateByProductId($productId, $enrichTemplate = true)
    {
        $templateQuery = $this->connection->createQueryBuilder();

        $template = $templateQuery->select('template.*')
            ->from('s_plugin_custom_products_template', 'template')
            ->join('template', 's_plugin_custom_products_template_product_relation', 'product', 'product.template_id = template.id')
            ->where('product.article_id = :productId')
            ->setParameter('productId', $productId)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);

        if (empty($template)) {
            return null;
        }

        if ($enrichTemplate) {
            return $this->enrichTemplate($template);
        }

        return $template;
    }

    /**
     * @param string $internalName
     * @return boolean
     */
    public function isInternalNameAssigned($internalName)
    {
        $query = $this->connection->createQueryBuilder();

        $result = $query->select('id')
            ->from('s_plugin_custom_products_template', 'template')
            ->where('internal_name = :internalName')
            ->setParameter(':internalName', $internalName)
            ->execute()
            ->fetchColumn();

        if ($result) {
            return false;
        }

        return true;
    }

    /**
     * @param integer $templateId
     * @return array
     */
    public function getOptionsByTemplateId($templateId)
    {
        $queryBuilder = $this->connection->createQueryBuilder();

        $options = $queryBuilder->select('*')
            ->from('s_plugin_custom_products_option')
            ->where('template_id = :templateId')
            ->setParameter('templateId', $templateId)
            ->orderBy('position')
            ->execute()
            ->fetchAll(\PDO::FETCH_ASSOC);

        foreach ($options as &$option) {
            $option['prices'] = $this->getPrices($option['id']);
            $option = $this->enrich($option);

            if (!$option['could_contain_values']) {
                continue;
            }

            $option['values'] = $this->getValuesByOptionId($option['id'], $option['type']);
        }

        return $options;
    }

    /**
     * @param integer $optionId
     * @param string $type
     * @return array
     */
    private function getValuesByOptionId($optionId, $type)
    {
        $queryBuilder = $this->connection->createQueryBuilder();

        $values = $queryBuilder->select('*')
            ->from('s_plugin_custom_products_value')
            ->where('option_id = :optionId')
            ->setParameter('optionId', $optionId)
            ->orderBy('position')
            ->execute()
            ->fetchAll(\PDO::FETCH_ASSOC);

        foreach ($values as &$value) {
            $value['prices'] = $this->getPrices(null, $value['id']);
            $value = $this->enrich($value);

            if ($type == 'imageselect' && $value['media_id']) {
                $value['image'] = $this->getMediaById($value['media_id']);
            }
        }

        return $values;
    }

    /**
     * Reads the prices by optionId OR by valueId.
     * it is important to make only one indication!
     *
     * @param null|integer $optionId
     * @param null|integer $valueId
     *
     * @return array
     *
     * @throws \Exception
     */
    public function getPrices($optionId = null, $valueId = null)
    {
        if (($optionId && $valueId) || (!$optionId && !$valueId)) {
            throw new \Exception('optionId OR valueId is needed!');
        }

        $queryBuilder = $this->connection->createQueryBuilder();
        $queryBuilder->select('*')->from('s_plugin_custom_products_price');

        if ($optionId) {
            $queryBuilder->where('option_id = :optionId')
                ->setParameter('optionId', $optionId);
        }

        if ($valueId) {
            $queryBuilder->where('value_id = :valueId')
                ->setParameter('valueId', $valueId);
        }

        return $queryBuilder->execute()->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * @param integer $id
     * @param boolean $basketCalculation
     * @return array|null
     */
    public function getOptionById($id, $basketCalculation = false)
    {
        if (!$id) {
            return null;
        }

        $queryBuilder = $this->connection->createQueryBuilder();

        $option = $queryBuilder->select('*')
            ->from('s_plugin_custom_products_option')
            ->where('id = :id')
            ->setParameter('id', $id)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);

        $option['prices'] = $this->getPrices($id);

        return $this->enrich($option, $basketCalculation);
    }

    /**
     * @param integer $id
     * @param boolean $basketCalculation
     * @return array|null
     */
    public function getValueById($id, $basketCalculation = false)
    {
        if (!$id) {
            return null;
        }

        $queryBuilder = $this->connection->createQueryBuilder();

        $values = $queryBuilder->select('*')
            ->from('s_plugin_custom_products_value')
            ->where('id = :id')
            ->setParameter('id', $id)
            ->execute()
            ->fetch(\PDO::FETCH_ASSOC);

        $values['prices'] = $this->getPrices(null, $id);

        return $this->enrich($values, $basketCalculation);
    }

    /**
     * @param integer $mediaId
     * @return array
     */
    private function getMediaById($mediaId)
    {
        $context = $this->contextService->getShopContext();

        return json_decode(json_encode($this->mediaService->get($mediaId, $context)), true);
    }

    /**
     * Enrich the template with all necessary data.
     *
     * @param array $template
     * @return array
     */
    private function enrichTemplate(array $template)
    {
        $template['options'] = $this->getOptionsByTemplateId($template['id']);

        if ($template['media_id']) {
            $template['media'] = $this->getMediaById($template['media_id']);
        }

        foreach ($template['options'] as &$option) {
            if ($option['type'] === ImageUploadType::TYPE) {
                $option['allowed_mime_types'] = json_encode(FileTypeWhitelist::$mimeTypeWhitelist['image']);
            }
        }

        return $template;
    }

    /**
     * Enrich objects with prices and tax Ids
     *
     * @param array $data
     * @param bool $basketCalculation
     * @return array
     * @throws \Exception
     */
    public function enrich(array $data, $basketCalculation = false)
    {
        if (empty($data['prices'])) {
            return $data;
        }

        $customerGroup = $this->contextService->getShopContext()->getCurrentCustomerGroup();

        $price = $this->getRightPrice($data['prices'], $customerGroup->getId());

        if (empty($price)) {
            return $data;
        }

        $price = $this->calculator->getPrice($price, $this->contextService->getShopContext(), $basketCalculation);
        $data = array_merge($data, $price);

        return $data;
    }

    /**
     * @param array $prices
     * @param integer $customerGroupId
     * @return null|array
     */
    private function getRightPrice(array $prices, $customerGroupId)
    {
        $fallbackId = $this->contextService->getShopContext()->getFallbackCustomerGroup()->getId();

        $defaultPrice = null;

        foreach ($prices as $price) {
            if ($price['customer_group_id'] == $customerGroupId) {
                return $price;
            }

            if ($price['customer_group_id'] == $fallbackId) {
                $defaultPrice = $price;
            }
        }

        return $defaultPrice;
    }
}
